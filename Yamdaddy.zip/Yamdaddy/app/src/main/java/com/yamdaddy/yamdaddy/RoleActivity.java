package com.yamdaddy.yamdaddy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class RoleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_role);
        setTitle("누누 육아 Plan_담당자별 Role");


        Button backToMain = findViewById(R.id.main_R);
        backToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "첫 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goMain = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(goMain);
            }
        });


        Button goContin = findViewById(R.id.cont_R);
        goContin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "컨틴전시 플랜으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goConti = new Intent(getApplicationContext(), ContinActivity.class);
                startActivity(goConti);
            }
        });


        Button goNext = findViewById(R.id.next_R);
        goNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "시간표 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goNex = new Intent(getApplicationContext(), ActionActivity.class);
                startActivity(goNex);
            }
        });


        Button goContact = findViewById(R.id.contact_R);
        goContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "연락처 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goCont = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(goCont);
            }
        });














    }
}
