package com.yamdaddy.yamdaddy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("누누 육아 Plan v.0.1");

        Button who = findViewById(R.id.who);
        who.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "누누 프로필로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goWho = new Intent(getApplicationContext(), TargetActivity.class);
                startActivity(goWho);
            }
        });

        Button cont = findViewById(R.id.cont);
        cont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "컨틴전시 플랜으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goCont = new Intent(getApplicationContext(), ContinActivity.class);
                startActivity(goCont);
            }
        });

        Button role = findViewById(R.id.role);
        role.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "담당자별 Role 로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goRole = new Intent(getApplicationContext(), RoleActivity.class);
                startActivity(goRole);
            }
        });

        Button act = findViewById(R.id.action);
        act.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "하루 Activity 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goAct = new Intent(getApplicationContext(), ActionActivity.class);
                startActivity(goAct);
            }
        });


        Button schedule = findViewById(R.id.schedule);
        schedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "일자별 주 담당자 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goSch = new Intent(getApplicationContext(), ScheduleActivity.class);
                startActivity(goSch);
            }
        });

        Button contact = findViewById(R.id.phone);
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "연락처화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goContact = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(goContact);
            }
        });




    }
}
