package com.yamdaddy.yamdaddy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ContactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        setTitle("누누 육아 Plan_연락처");





        Button backToMain = findViewById(R.id.main_C);
        backToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "첫 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goMain = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(goMain);
            }
        });


        Button goContin = findViewById(R.id.cont_C);
        goContin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "컨틴전시 플랜으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goConti = new Intent(getApplicationContext(), ContinActivity.class);
                startActivity(goConti);
            }
        });














    }
}
