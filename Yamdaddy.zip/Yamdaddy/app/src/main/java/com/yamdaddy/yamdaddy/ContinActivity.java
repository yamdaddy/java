package com.yamdaddy.yamdaddy;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ContinActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contin);
        setTitle("누누 육아 Plan_위기상황 대응 메뉴얼");


        Button backToMain = findViewById(R.id.main);
        backToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "첫 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goMain = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(goMain);
            }
        });

        Button callHos = findViewById(R.id.hospital);
        callHos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel: 01012341231"));
                startActivity(intent);

            }
        });

        Button goNext = findViewById(R.id.next);
        goNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "연락처 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goNex = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(goNex);
            }
        });

        final Button goContact = findViewById(R.id.contact);
        goContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "연락처 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goCont = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(goCont);
            }
        });






    }
}
