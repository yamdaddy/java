package com.yamdaddy.yamdaddy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ScheduleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);
        setTitle("누누 육아 Plan_일자별 계획");


        Button backToMain = findViewById(R.id.main_S);
        backToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "첫 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goMain = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(goMain);
            }
        });


        Button goContin = findViewById(R.id.cont_S);
        goContin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "컨틴전시 플랜으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goConti = new Intent(getApplicationContext(), ContinActivity.class);
                startActivity(goConti);
            }
        });


        Button goNext = findViewById(R.id.next_S);
        goNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "컨틴전시 플랜으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goNex = new Intent(getApplicationContext(), ContinActivity.class);
                startActivity(goNex);
            }
        });


        Button goContact = findViewById(R.id.contact_S);
        goContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "연락처 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goCont = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(goCont);
            }
        });











    }
}
