package com.yamdaddy.yamdaddy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ActionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action);
        setTitle("누누 육아 Plan_주요 일정");


        Button backToMain = findViewById(R.id.main_A);
        backToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "첫 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goMain = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(goMain);
            }
        });


        Button goContin = findViewById(R.id.cont_A);
        goContin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "컨틴전시 플랜으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goConti = new Intent(getApplicationContext(), ContinActivity.class);
                startActivity(goConti);
            }
        });


        Button goNext = findViewById(R.id.next_A);
        goNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "스케쥴 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goNex = new Intent(getApplicationContext(), ScheduleActivity.class);
                startActivity(goNex);
            }
        });


        Button goContact = findViewById(R.id.contact_A);
        goContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "연락처 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent goCont = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(goCont);
            }
        });
















    }
}
