package com.yamdaddy.restart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class DietActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet);

        Button back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "첫 화면으로 돌아갑니다", Toast.LENGTH_SHORT).show();
                Intent goback = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(goback);
            }
        });

        Button plan = findViewById(R.id.plan);
        plan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "계획 화면으로 갑니다", Toast.LENGTH_SHORT).show();
                Intent setplan = new Intent(getApplicationContext(), PlanActivity.class);
                startActivity(setplan);
            }
        });


    }
}
